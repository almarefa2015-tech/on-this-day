const fs = require('fs');
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
if (fs.existsSync(manifestPath)) {
  let xml = fs.readFileSync(manifestPath, 'utf8');
  if (!xml.includes('com.google.android.gms.ads.APPLICATION_ID')) {
    const meta = '        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-2190356904946294~4400577603"/>\n    </application>';
    xml = xml.replace('</application>', meta);
    fs.writeFileSync(manifestPath, xml, 'utf8');
    console.log('Injected AdMob App ID into AndroidManifest.xml');
  }
}
